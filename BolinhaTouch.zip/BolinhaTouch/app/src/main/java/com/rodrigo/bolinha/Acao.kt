package com.rodrigo.bolinha

enum class Acao(val id: String, val rotulo: String, val padrao: Boolean) {
    VOL_MAIS("vol_mais", "Volume +", true),
    VOL_MENOS("vol_menos", "Volume −", true),
    MUDO("mudo", "Mudo", true),
    LANTERNA("lanterna", "Lanterna", true),
    CAMERA("camera", "Câmera", true),
    HOME("home", "Início", true),
    VOLTAR("voltar", "Voltar", true),
    RECENTES("recentes", "Recentes", false),
    NOTIFICACOES("notificacoes", "Notificações", false),
    BLOQUEAR("bloquear", "Bloquear tela", false),
    PRINT("print", "Captura de tela", false);
}
