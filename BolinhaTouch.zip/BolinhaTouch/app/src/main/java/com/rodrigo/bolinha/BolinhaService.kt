package com.rodrigo.bolinha

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast

class BolinhaService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private var bolinha: View? = null
    private var painel: View? = null
    private var lp: WindowManager.LayoutParams? = null
    private var lanternaLigada = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        criarBolinha()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        fecharPainel()
        bolinha?.let { runCatching { wm.removeView(it) } }
        bolinha = null
        super.onDestroy()
    }

    private fun criarBolinha() {
        val tam = dp(52)
        val v = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(170, 40, 40, 40))
                setStroke(dp(3), Color.argb(200, 255, 255, 255))
            }
        }
        val params = WindowManager.LayoutParams(
            tam, tam,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - tam
            y = resources.displayMetrics.heightPixels / 3
        }
        lp = params

        var iniX = 0; var iniY = 0; var toqueX = 0f; var toqueY = 0f; var moveu = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    iniX = params.x; iniY = params.y
                    toqueX = e.rawX; toqueY = e.rawY; moveu = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - toqueX).toInt()
                    val dy = (e.rawY - toqueY).toInt()
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moveu = true
                    if (moveu) {
                        params.x = iniX + dx
                        params.y = iniY + dy
                        wm.updateViewLayout(v, params)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moveu) abrirPainel()
            }
            true
        }
        wm.addView(v, params)
        bolinha = v
    }

    private fun acoesAtivas(): List<Acao> {
        val prefs = getSharedPreferences("bolinha", Context.MODE_PRIVATE)
        val ids = prefs.getStringSet("acoes", null)
            ?: Acao.values().filter { it.padrao }.map { it.id }.toSet()
        return Acao.values().filter { it.id in ids }
    }

    private fun abrirPainel() {
        if (painel != null) { fecharPainel(); return }
        val fundo = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(120, 0, 0, 0))
            setOnClickListener { fecharPainel() }
        }
        val caixa = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.argb(240, 30, 30, 30))
            }
        }
        val lista = acoesAtivas()
        val colunas = 3
        lista.chunked(colunas).forEach { linha ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            linha.forEach { a ->
                row.addView(Button(this).apply {
                    text = a.rotulo
                    isAllCaps = false
                    textSize = 13f
                    setOnClickListener { executar(a) }
                }, LinearLayout.LayoutParams(dp(104), dp(64)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            caixa.addView(row)
        }
        fundo.addView(caixa, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ))
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(fundo, params)
        painel = fundo
    }

    private fun fecharPainel() {
        painel?.let { runCatching { wm.removeView(it) } }
        painel = null
    }

    private fun executar(a: Acao) {
        when (a) {
            Acao.VOL_MAIS -> audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            Acao.VOL_MENOS -> audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            Acao.MUDO -> audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
            Acao.LANTERNA -> alternarLanterna()
            Acao.CAMERA -> {
                fecharPainel()
                startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            Acao.HOME -> { fecharPainel(); performGlobalAction(GLOBAL_ACTION_HOME) }
            Acao.VOLTAR -> { fecharPainel(); performGlobalAction(GLOBAL_ACTION_BACK) }
            Acao.RECENTES -> { fecharPainel(); performGlobalAction(GLOBAL_ACTION_RECENTS) }
            Acao.NOTIFICACOES -> { fecharPainel(); performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) }
            Acao.BLOQUEAR -> {
                fecharPainel()
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            }
            Acao.PRINT -> {
                fecharPainel()
                if (Build.VERSION.SDK_INT >= 28) {
                    // pequeno atraso para o painel sumir antes da captura
                    bolinha?.postDelayed({ performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) }, 400)
                }
            }
        }
    }

    private fun alternarLanterna() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: run {
                Toast.makeText(this, "Sem lanterna disponível", Toast.LENGTH_SHORT).show(); return
            }
            lanternaLigada = !lanternaLigada
            cm.setTorchMode(id, lanternaLigada)
        } catch (e: Exception) {
            Toast.makeText(this, "Erro na lanterna", Toast.LENGTH_SHORT).show()
        }
    }
}
