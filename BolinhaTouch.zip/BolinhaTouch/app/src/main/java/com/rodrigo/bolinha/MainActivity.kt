package com.rodrigo.bolinha

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bolinha", Context.MODE_PRIVATE)
        val atuais = prefs.getStringSet("acoes", null)
            ?: Acao.values().filter { it.padrao }.map { it.id }.toSet()
        val marcadas = atuais.toMutableSet()
        val p = (16 * resources.displayMetrics.density).toInt()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p, p, p, p)
        }
        raiz.addView(TextView(this).apply {
            text = "Bolinha Touch"
            textSize = 24f
        })
        raiz.addView(TextView(this).apply {
            text = "1) Toque no botão abaixo, procure \"Bolinha Touch\" e ative.\n2) Escolha as funções que quer na bolinha."
            setPadding(0, p / 2, 0, p / 2)
        })
        raiz.addView(Button(this).apply {
            text = "Ativar nas configurações de acessibilidade"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        raiz.addView(TextView(this).apply {
            text = "Funções da bolinha:"
            setPadding(0, p, 0, 0)
        })
        Acao.values().forEach { a ->
            raiz.addView(CheckBox(this).apply {
                text = a.rotulo
                isChecked = a.id in marcadas
                setOnCheckedChangeListener { _, on ->
                    if (on) marcadas.add(a.id) else marcadas.remove(a.id)
                    prefs.edit().putStringSet("acoes", HashSet(marcadas)).apply()
                }
            })
        }
        raiz.addView(TextView(this).apply {
            text = "\nDica: segure e arraste a bolinha para mudar de lugar."
            gravity = Gravity.START
        })
        setContentView(ScrollView(this).apply { addView(raiz) })
    }
}
